/**
 * o pc deve escolher de 1 a 3
 * 
 * 1- pedra
 * 2- papel
 * 3- tesoura
 * (randon)
 * 
 * voce escolhe tambem entre
 * 
 * 1- pedra
 * 2- papel
 * 3- tesoura
 * (swith case)
 * 
 * mostrar o vencedor
*/